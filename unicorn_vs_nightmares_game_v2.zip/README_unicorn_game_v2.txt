Unicorn vs. Nightmares - easier version

Changes made:
- Level 1 starts slower
- Obstacles are more spread out
- Unicorn now has 7 lives
- Repeated Space presses let the unicorn fly/flap upward
- Rainbows are larger and easier to see

How to play:
- Open the HTML file in a browser
- Press Enter to start
- Left/Right arrows: move
- Space: jump and keep pressing to fly
- F: shoot rainbow
- P: pause
